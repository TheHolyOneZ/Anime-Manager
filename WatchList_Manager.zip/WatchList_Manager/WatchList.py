import undetected_chromedriver as uc
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import json
import time
import concurrent.futures
from threading import Lock
import pickle
import os
import webbrowser
import psutil
import qrcode
from http.server import HTTPServer, SimpleHTTPRequestHandler
import socket
import threading
import subprocess

file_lock = Lock()

def close_opera():
    opera_processes = [
        "opera.exe",
        "OperaGX.exe",
        "opera_crashreporter.exe",
        "opera_autoupdate.exe"
    ]
    
    for proc in psutil.process_iter(['name']):
        try:
            if proc.info['name'] in opera_processes:
                proc.kill()
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass

def load_config():
    with open('config.json', 'r') as f:
        config = json.load(f)
        return {
            'email': config['.get_E-Mail'],
            'password': config['.get_Password'],
            'cookie': config['.get_Cookie'],
            'ngrok_token': config['.get_NgrokToken']
        }

def save_cookies(driver):
    with open('cookies.pkl', 'wb') as f:
        pickle.dump(driver.get_cookies(), f)

def load_cookies(driver, config):
    try:
        driver.add_cookie(config['cookie'])
        return True
    except:
        if os.path.exists('cookies.pkl'):
            with open('cookies.pkl', 'rb') as f:
                cookies = pickle.load(f)
                for cookie in cookies:
                    driver.add_cookie(cookie)
            return True
    return False

def check_login_status(driver):
    try:
        WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, ".watchlist-container"))
        )
        return True
    except:
        return False

def login(driver, config):
    print("Starting login process...")
    print(f"Using email: {config['email']}")
    
    driver.get("https://aniworld.to/login")
    time.sleep(2)
    
    print("Filling email field...")
    email_field = WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.NAME, "email"))
    )
    email_field.clear()
    email_field.send_keys(config['email'])
    time.sleep(0.8)
    
    print("Filling password field...")
    password_field = WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.NAME, "password"))
    )
    password_field.clear()
    password_field.send_keys(config['password'])
    time.sleep(0.8)
    
    print("Clicking checkbox...")
    checkbox = WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.CSS_SELECTOR, ".icheckbox_square-blue input[type='checkbox']"))
    )
    driver.execute_script("arguments[0].click();", checkbox)
    time.sleep(0.8)
    
    print("Clicking submit button...")
    submit_button = WebDriverWait(driver, 10).until(
        EC.element_to_be_clickable((By.CSS_SELECTOR, "input.button.blue[type='submit']"))
    )
    driver.execute_script("arguments[0].click();", submit_button)
    
    time.sleep(3)
    print("Saving cookies...")
    save_cookies(driver)

def check_already_logged_in(driver):
    try:
        current_url = driver.current_url
        if "account/watchlist" in current_url:
            WebDriverWait(driver, 5).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, ".anime-item"))
            )
            return True
        return False
    except:
        return False

def get_user_preference():
    print("\nWhat would you like to extract from your watchlist?")
    print("1. Only Series")
    print("2. Only Movies") 
    print("3. Both Series and Movies")
    
    while True:
        choice = input("Enter your choice (1-3): ")
        if choice in ['1', '2', '3']:
            return choice

def process_anime(anime_elements, preference, user_data_dir):
    results = []
    
    for anime in anime_elements:
        try:
            name = anime.find_element(By.CSS_SELECTOR, "h3").text
            link = anime.find_element(By.CSS_SELECTOR, "a").get_attribute("href")
            cover_img = anime.find_element(By.CSS_SELECTOR, "img").get_attribute("src")
            
            if preference == '3':
                results.append({
                    "name": name,
                    "link": link,
                    "cover_image": cover_img,
                    "type": ""
                })
                print(f"Added: {name}")
                continue
                
            check_options = uc.ChromeOptions()
            check_options.add_argument(f'--user-data-dir={user_data_dir}')
            check_options.add_argument('--headless')
            check_driver = uc.Chrome(options=check_options)
            
            try:
                print(f"\nChecking: {name}")
                check_driver.get(link)
                time.sleep(2)
                
                episodes = check_driver.find_elements(By.CSS_SELECTOR, ".episode-list .episode")
                is_movie = len(episodes) == 1
                episode_count = len(episodes)
                print(f"✓ Found {episode_count} episodes")
                
                if not ((preference == '1' and is_movie) or (preference == '2' and not is_movie)):
                    results.append({
                        "name": name,
                        "link": link,
                        "cover_image": cover_img,
                        "type": "Movie" if is_movie else "Series",
                        "episodes": episode_count
                    })
                    print(f"Added: {name}")
            finally:
                check_driver.quit()
                
        except Exception as e:
            print(f"× Error processing {name}: {str(e)}")
            
    return results


def generate_html_preview():
    with open('watchlist.md', 'r', encoding='utf-8') as f:
        lines = f.readlines()
    
    html_content = []
    for line in lines:
        if line.startswith('# '):
            title = line.replace('# ', '').strip()
            html_content.append(f'<h1 class="main-title">{title}</h1>')
        elif line.startswith('*') and 'curated' in line:
            subtitle = line.strip()
            html_content.append(f'<p class="subtitle">{subtitle}</p>')
        elif '[![' in line:
            name = line[line.find('[[')+2:line.find(']')]
            img_url = line[line.find('(')+1:line.find(')')]
            link = line[line.rfind('(')+1:line.rfind(')')]
            html_content.append(f'''
                <div class="anime-card">
                    <a href="{link}" class="anime-link">
                        <img src="{img_url}" alt="{name}" loading="lazy" />
                        <div class="anime-overlay">
                            <span class="anime-title">{name}</span>
                        </div>
                    </a>
                </div>
            ''')
        elif '### ' in line:
            name = line.replace('### ', '').strip()
            html_content.append(f'<h3 class="anime-heading">{name}</h3>')
        elif '[▶️ Watch Now]' in line:
            link = line[line.find('(')+1:line.find(')')]
            html_content.append(f'<a href="{link}" class="watch-button" target="_blank">▶️ Watch Now</a>')
        elif '---' in line:
            html_content.append('<hr class="divider">')

    css_additions = """
        :root {
            --primary-color: #0366d6;
            --hover-color: #035fc7;
            --text-color: #24292e;
            --bg-color: #f6f8fa;
            --card-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        
        .main-title {
            text-align: center;
            font-size: 2.5em;
            margin-bottom: 10px;
            color: var(--text-color);
            text-shadow: 2px 2px 4px rgba(0,0,0,0.1);
        }
        
        .subtitle {
            text-align: center;
            font-style: italic;
            color: #666;
            margin-bottom: 30px;
        }
        
        .anime-card {
            text-align: center;
            padding: 20px;
            margin: 20px 0;
            transition: transform 0.3s;
        }
        
        .anime-card:hover {
            transform: translateY(-5px);
        }
        
        .anime-link {
            display: inline-block;
            position: relative;
            overflow: hidden;
            border-radius: 8px;
            box-shadow: var(--card-shadow);
        }
        
        .anime-overlay {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            background: rgba(0,0,0,0.7);
            color: white;
            padding: 10px;
            transform: translateY(100%);
            transition: transform 0.3s;
        }
        
        .anime-link:hover .anime-overlay {
            transform: translateY(0);
        }
        
        .anime-title {
            font-weight: bold;
            font-size: 0.9em;
        }
        
        .anime-heading {
            text-align: center;
            margin: 20px 0;
            color: var(--text-color);
        }
        
        .divider {
            border: 0;
            height: 1px;
            background: linear-gradient(to right, transparent, #666, transparent);
            margin: 30px 0;
        }
        
        @media (max-width: 768px) {
            body {
                padding: 10px;
            }
            .main-title {
                font-size: 2em;
            }
            img {
                max-width: 150px;
            }
            .anime-overlay {
                transform: translateY(0);
            }
        }
        
        @media (prefers-color-scheme: dark) {
            :root {
                --text-color: #e1e4e8;
                --bg-color: #24292e;
                --card-shadow: 0 4px 8px rgba(0,0,0,0.3);
            }
            body {
                background: var(--bg-color);
                color: var(--text-color);
            }
            .subtitle {
                color: #999;
            }
        }
    """

    html_template = f"""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="A curated collection of anime series and movies">
        <title>Anime Watchlist</title>
        <style>
            body {{
                max-width: 900px;
                margin: 0 auto;
                padding: 20px;
                font-family: system-ui, -apple-system, sans-serif;
                background: var(--bg-color);
                color: var(--text-color);
            }}
            img {{
                max-width: 200px;
                border-radius: 8px;
                vertical-align: middle;
                transition: transform 0.3s;
            }}
            .watch-button {{
                display: inline-block;
                padding: 10px 20px;
                background: var(--primary-color);
                color: white;
                text-decoration: none;
                border-radius: 6px;
                margin: 10px;
                transition: background 0.3s;
            }}
            .watch-button:hover {{
                background: var(--hover-color);
            }}
            {css_additions}
        </style>
    </head>
    <body>
        {''.join(html_content)}
    </body>
    </html>
    """
    
    with open('watchlist_preview.html', 'w', encoding='utf-8') as f:
        f.write(html_template)

def generate_sharing_options():
    config = load_config()
    
    try:
        import qrcode
        from pyngrok import ngrok
        import os
    except ImportError:
        print("Installing required dependencies...")
        subprocess.check_call(['pip', 'install', 'qrcode', 'pillow', 'pyngrok'])
        import qrcode
        from pyngrok import ngrok
        import os

    script_dir = os.path.dirname(os.path.abspath(__file__))
    os.chdir(script_dir)
    
    port = 8000
    
    ngrok.set_auth_token(config['ngrok_token'])
    
    server = HTTPServer(('0.0.0.0', port), SimpleHTTPRequestHandler)
    thread = threading.Thread(target=server.serve_forever)
    thread.daemon = True
    thread.start()
    
    public_url = ngrok.connect(port).public_url
    share_url = f"{public_url}/watchlist_preview.html"
    
    qr = qrcode.QRCode(version=1, box_size=10, border=5)
    qr.add_data(share_url)
    qr.make(fit=True)
    qr_image = qr.make_image(fill_color="black", back_color="white")
    qr_image.save("watchlist_qr.png")
    
    print(f"\nShare your watchlist worldwide!")
    print(f"1. Scan the QR code in 'watchlist_qr.png'")
    print(f"2. Or share this link: {share_url}")
    print(f"3. Press Ctrl+C to stop sharing")
    
    try:
        while True:
            input()
    except KeyboardInterrupt:
        ngrok.kill()
        server.shutdown()
        print("\nSharing stopped!")


def get_watchlist():
    close_opera()
    config = load_config()
    options = uc.ChromeOptions()
    user_data_dir = 'C:\\Users\\zoryx\\AppData\\Roaming\\Opera Software\\Opera GX Stable'
    options.add_argument(f'--user-data-dir={user_data_dir}')
    driver = uc.Chrome(options=options)
    
    driver.get("https://aniworld.to/account/watchlist")
    
    user_input = input("Are you already logged in? (yes/no): ").lower()
    
    if user_input == 'yes':
        print("Proceeding with watchlist extraction...")
    else:
        if load_cookies(driver, config):
            driver.get("https://aniworld.to/account/watchlist")
            if not check_login_status(driver):
                print("Cookie login failed, using credentials...")
                login(driver, config)
        else:
            print("No cookies found, using credentials...")
            login(driver, config)
    
    preference = get_user_preference()
    
    print("Loading watchlist...")
    anime_elements = WebDriverWait(driver, 10).until(
        EC.presence_of_all_elements_located((By.CSS_SELECTOR, ".col-md-15.col-sm-3.col-xs-6"))
    )
    
    print(f"Found {len(anime_elements)} anime in watchlist")
    
    batch_size = max(1, len(anime_elements) // 5)
    anime_batches = [anime_elements[i:i + batch_size] for i in range(0, len(anime_elements), batch_size)]
    
    anime_list = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
        future_to_anime = {
            executor.submit(process_anime, batch, preference, user_data_dir): batch 
            for batch in anime_batches
        }
        
        for future in concurrent.futures.as_completed(future_to_anime):
            try:
                results = future.result()
                anime_list.extend(results)
                print(f"Processed batch, total anime collected: {len(anime_list)}")
            except Exception as e:
                print(f"Error processing anime: {str(e)}")
    
    with file_lock:
        with open("watchlist.txt", "w", encoding="utf-8") as f:
            for anime in anime_list:
                f.write(f"{anime['name']} ({anime['type']}) - {anime['link']}\n")
        
        with open("watchlist.json", "w", encoding="utf-8") as f:
            json.dump(anime_list, f, indent=4, ensure_ascii=False)
        
        with open("watchlist.md", "w", encoding="utf-8") as f:
            f.write("# 🎬 My Anime Watchlist Collection\n\n")
            f.write("*A curated collection of amazing anime series and movies*\n\n")
            f.write("---\n\n")
            
            for i, anime in enumerate(anime_list):
                emojis = ["🌟", "✨", "💫", "⭐", "🎯", "🎬", "🎥"]
                emoji = emojis[i % len(emojis)]
                
                f.write(f"### {emoji} {anime['name']} ({anime['type']})\n\n")
                f.write("<div align='center'>\n\n")
                f.write(f"[![{anime['name']}]({anime['cover_image']})]({anime['link']})\n\n")
                f.write(f"[▶️ Watch Now]({anime['link']})\n\n")
                f.write("</div>\n\n")
                f.write("---\n\n")
            
            f.write("\n\n<div align='center'>\n\n")
            f.write("*Generated with ❤️ by Anime Watchlist Manager by TheZ*\n\n")
            f.write("</div>")
    
    driver.quit()
    print("Watchlist saved successfully in TXT, JSON, and MD formats!")
    print(f"Saved {len(anime_list)} anime to files")
    
    generate_html_preview()
    
    print("\nWould you like to see a preview of your watchlist? (yes/no)")
    preview_choice = input().lower()
    if preview_choice == 'yes':
        webbrowser.open('file://' + os.path.realpath('watchlist_preview.html'))
        
    print("\nWould you like to share your watchlist with mobile devices? (yes/no)")
    share_choice = input().lower()
    if share_choice == 'yes':
        generate_sharing_options()

if __name__ == "__main__":
    get_watchlist()
