import undetected_chromedriver as uc
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import json
import time
import concurrent.futures
from threading import Lock
import pickle
import os
file_lock = Lock()
def load_config():
    with open('config.json', 'r') as f:
        config = json.load(f)
        return {
            'email': config['.get_E-Mail'],
            'password': config['.get_Password'],
            'cookie': config['.get_Cookie']
        }
def save_cookies(driver):
    with open('cookies.pkl', 'wb') as f:
        pickle.dump(driver.get_cookies(), f)

def load_cookies(driver, config):
    try:
        driver.add_cookie(config['cookie'])
        return True
    except:
        if os.path.exists('cookies.pkl'):
            with open('cookies.pkl', 'rb') as f:
                cookies = pickle.load(f)
                for cookie in cookies:
                    driver.add_cookie(cookie)
            return True
    return False

def check_login_status(driver):
    try:
        WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, ".watchlist-container"))
        )
        return True
    except:
        return False

def login(driver, config):
    login_button = WebDriverWait(driver, 10).until(
        EC.element_to_be_clickable((By.CSS_SELECTOR, ".login-button"))
    )
    login_button.click()
    
    email_field = WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.NAME, "email"))
    )
    password_field = driver.find_element(By.NAME, "password")
    
    email_field.send_keys(config['email'])
    password_field.send_keys(config['password'])
    
    submit_button = driver.find_element(By.CSS_SELECTOR, ".submit-button")
    submit_button.click()
    
    time.sleep(3)
    save_cookies(driver)

def process_anime(anime):
    name = anime.find_element(By.CSS_SELECTOR, ".title").text
    link = anime.find_element(By.CSS_SELECTOR, "a").get_attribute("href")
    cover_img = anime.find_element(By.CSS_SELECTOR, "img").get_attribute("src")
    
    return {
        "name": name,
        "link": link,
        "cover_image": cover_img
    }
def check_already_logged_in(driver):
    try:
        current_url = driver.current_url
        if "account/watchlist" in current_url:
            WebDriverWait(driver, 5).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, ".anime-item"))
            )
            return True
        return False
    except:
        return False
    
def process_anime(anime):
    name = anime.find_element(By.CSS_SELECTOR, "h3").text
    link = anime.find_element(By.CSS_SELECTOR, "a").get_attribute("href")
    cover_img = anime.find_element(By.CSS_SELECTOR, "img").get_attribute("src")
    
    return {
        "name": name,
        "link": link,
        "cover_image": cover_img
    }

def get_watchlist():
    config = load_config()
    options = uc.ChromeOptions()
    options.add_argument('--user-data-dir=C:\\Users\\zoryx\\AppData\\Roaming\\Opera Software\\Opera GX Stable')
    driver = uc.Chrome(options=options)
    
    driver.get("https://aniworld.to/account/watchlist")
    
    user_input = input("Are you already logged in? (yes/no): ").lower()
    
    if user_input == 'yes':
        print("Proceeding with watchlist extraction...")
    else:
        if load_cookies(driver, config):
            driver.get("https://aniworld.to/account/watchlist")
            if not check_login_status(driver):
                print("Cookie login failed, using credentials...")
                login(driver, config)
        else:
            print("No cookies found, using credentials...")
            login(driver, config)
    
    print("Loading watchlist...")
    anime_elements = WebDriverWait(driver, 10).until(
        EC.presence_of_all_elements_located((By.CSS_SELECTOR, ".col-md-15.col-sm-3.col-xs-6"))
    )
    
    print(f"Found {len(anime_elements)} anime in watchlist")
    
    anime_list = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
        future_to_anime = {executor.submit(process_anime, anime): anime for anime in anime_elements}
        
        for future in concurrent.futures.as_completed(future_to_anime):
            try:
                data = future.result()
                anime_list.append(data)
                print(f"Added: {data['name']}")
            except Exception as e:
                print(f"Error processing anime: {e}")
    
    print(f"\nTotal anime collected: {len(anime_list)}")
    
    with file_lock:
        with open("watchlist.txt", "w", encoding="utf-8") as f:
            for anime in anime_list:
                f.write(f"{anime['name']} - {anime['link']}\n")
        
        with open("watchlist.json", "w", encoding="utf-8") as f:
            json.dump(anime_list, f, indent=4, ensure_ascii=False)
        
        with open("watchlist.md", "w", encoding="utf-8") as f:
            # Stylish header
            f.write("# 🎬 My Anime Watchlist Collection\n\n")
            f.write("*A curated collection of amazing anime series*\n\n")
            f.write("---\n\n")
            
            for i, anime in enumerate(anime_list):
                emojis = ["🌟", "✨", "💫", "⭐", "🎯", "🎬", "🎥"]
                emoji = emojis[i % len(emojis)]
                
                f.write(f"### {emoji} {anime['name']}\n\n")
                f.write("<div align='center'>\n\n")
                f.write(f"[![{anime['name']}]({anime['cover_image']})]({anime['link']})\n\n")
                f.write(f"[▶️ Watch Now]({anime['link']})\n\n")
                f.write("</div>\n\n")
                f.write("---\n\n")
            
            f.write("\n\n<div align='center'>\n\n")
            f.write("*Generated with ❤️ by Anime Watchlist Manager by TheZ*\n\n")
            f.write("</div>")
    
    driver.quit()
    print("Watchlist saved successfully in TXT, JSON, and MD formats!")
    print(f"Saved {len(anime_list)} anime to files")

if __name__ == "__main__":
    get_watchlist()


# Made by TheZ
