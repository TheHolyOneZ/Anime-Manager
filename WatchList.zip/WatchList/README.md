# Requirements
- undetected-chromedriver
- selenium
- concurrent-futures

Run `requirements.bat` to install all dependencies automatically.
